<nav>
    <ul>
        <li><a href="<?php echo e(url('/home')); ?>"><img src="<?php echo e(asset('images/logo.png')); ?>" alt="logo"></a></li>
        <li><a href="<?php echo e(url('/login')); ?>"><span>Login</span></a></li>
    </ul>
</nav>
<?php /**PATH D:\Kuliah\Semester 8\Program TA\program_TA\tugas-akhir\resources\views/includes/user_navbar.blade.php ENDPATH**/ ?>