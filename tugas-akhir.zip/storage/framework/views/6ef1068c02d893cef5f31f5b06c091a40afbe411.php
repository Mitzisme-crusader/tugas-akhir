<?php $__env->startSection('title'); ?>
<title>Admin</title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('style'); ?>
<link rel="stylesheet" href="<?php echo e(asset('css/admin.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="content">
    <section>
        <h1>List Customer</h1>
        <div class="table-wrapper">
            <table>
                <thead>
                    <th>No</th>
                    <th>Nama</th>
                    <th>email</th>
                    <th>negara</th>
                    <th>nomor telepon</th>
                    <th>edit</th>
                    <th>delete</th>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $list_customer; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $customer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($customer->id_customer); ?></td>
                        <td><?php echo e($customer->nama_customer); ?></td>
                        <td><?php echo e($customer->email_customer); ?></td>
                        <td><?php echo e($customer->negara_customer); ?></td>
                        <td><?php echo e($customer->nomor_telepon_customer); ?></td>
                        <td>
                            <form action="<?php echo e(url('admin/edit_customer')); ?>" method="get">
                                <?php echo e(csrf_field()); ?>

                                <input type="hidden" name="id_customer" value="<?php echo e($customer->id_customer); ?>">
                                <button type="submit" class="button"><span>Edit</span></button>
                            </form>
                        </td>
                        <td>
                            <form action="<?php echo e(url('admin/delete_customer')); ?>" method="post">
                                <?php echo e(csrf_field()); ?>

                                <input type="hidden" name="id_customer" value="<?php echo e($customer->id_customer); ?>">
                                <button type="submit" class="button"><span>Delete</span></button>
                            </form>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
                
            </table>
        </div>
    </section>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.admin_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Kuliah\Semester 8\Program TA\program_TA\tugas-akhir\resources\views/pages/admin/list_customer.blade.php ENDPATH**/ ?>