<nav>
    <ul>
        <li><a href="<?php echo e(url('/home')); ?>"><img src="<?php echo e(asset('images/logo.jpg')); ?>" alt="logo"></a></li>
        <li><a href="<?php echo e(url('/login')); ?>"><span>Login</span></a></li>
        <li><a><span>Register</span></a></li>
        <li><a><span>Register</span></a></li>
    </ul>
</nav>
<?php /**PATH D:\Kuliah\Semester 8\Program TA\program_TA\resources\views/includes/user_navbar.blade.php ENDPATH**/ ?>