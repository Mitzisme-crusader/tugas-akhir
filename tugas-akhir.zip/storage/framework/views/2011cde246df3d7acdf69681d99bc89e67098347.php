<footer>
    &copy;
</footer>
<?php /**PATH D:\Kuliah\Semester 8\Program TA\program_TA\resources\views/includes/footer.blade.php ENDPATH**/ ?>