<?php $__env->startSection('title'); ?>
<title>Admin</title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('style'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('css/admin.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/list_document_SPK.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="content" style="width: 75%">
    <section >
        <h1 style="display:inline-block">List Dokumen Simpan Berjalan</h1>
        <div class="search-container">
            <form action="<?php echo e(url('admin/search_dokumen_simpan_berjalan')); ?>" method="GET" style="display: inline-block">
                <div style="display: inline-block">
                    <div style="display: block">
                        <input id ="query_search" type="text" placeholder="Search.." name="query_search">
                        <label style="height: 50px;width:50px"> In</label>
                        <select name="list_option_table" class="list_option_table" id="list_option_table">
                            <option value="id_dokumen_simpan_berjalan">ID dokumen simpan berjalan</option>
                            <option value="nomor_SO">Nomor SO</option>
                            <option value="nama_customer">Nama Customer</option>
                        </select>
                    </div>
                    <div style="display: block">
                        <?php if($range_month == ""): ?>
                            <input type="month" class="input_search_date_tabel" name="range_month" value="<?php echo date('Y-m'); ?>">
                        <?php else: ?>
                            <input type="month" class="input_search_date_tabel" name="range_month" value=<?php echo e($range_month); ?>>
                        <?php endif; ?>
                    </div>
                </div>
                <div style="display: inline-block;height:44px">
                    <button type="submit" style="display: inline"><i class="fa fa-search"></i></button>
                </div>
            </form>
        </div>
        <div class="table-wrapper">
            <table>
                <thead>
                    <th>Id_dokumen</th>
                    <th>Nomor SO</th>
                    <th>Nomor Aju</th>
                    <th>Consignee</th>
                    <th>Nama Customer</th>
                    <th>Estimated Time Arrival</th>
                    <th>Kode Warna</th>
                    <th>edit</th>
                    <th>delete</th>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $list_dokumen_simpan_berjalan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dokumen_simpan_berjalan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($dokumen_simpan_berjalan->id_dokumen_simpan_berjalan); ?></td>
                        <td><?php echo e($dokumen_simpan_berjalan->nomor_SO); ?></td>
                        <td><?php echo e($dokumen_simpan_berjalan->nomor_aju); ?></td>
                        <td><?php echo e($dokumen_simpan_berjalan->consignee); ?></td>
                        <td><?php echo e($dokumen_simpan_berjalan->nama_customer); ?></td>
                        <?php if($dokumen_simpan_berjalan->ETA == null): ?>
                            <td>N\A</td>
                        <?php else: ?>
                            <td><?php echo e(date('d-m-Y',strtotime($dokumen_simpan_berjalan->ETA))); ?>

                                <?php if($dokumen_simpan_berjalan->sending == null): ?>
                                    <span><i class="fas fa-exclamation-circle"></i></span>
                                <?php endif; ?>
                            </td>
                        <?php endif; ?>
                        <?php if($dokumen_simpan_berjalan->option_pengiriman == "jasa"): ?>
                            <td style="background-color: cornflowerblue"><span><i class="fas fa-people-carry"></i></span></td>
                        <?php elseif($dokumen_simpan_berjalan->option_pengiriman == "local"): ?>
                            <td style="background-color: grey"><span><i class="fas fa-people-carry"></i></span></td>'
                        <?php elseif($dokumen_simpan_berjalan->option_container == "LCL"): ?>
                            <td style="background-color: greenyellow"><span><i class="fas fa-people-carry"></i></span></td>
                        <?php elseif($dokumen_simpan_berjalan->opsi_surat_penjaluran == "SPJM"): ?>
                            <td style="background-color: red"><span><i class="fas fa-people-carry"></i></span></td>
                        <?php elseif($dokumen_simpan_berjalan->opsi_surat_penjaluran == "SPJK"): ?>
                            <td style="background-color: yellow"><span><i class="fas fa-people-carry"></i></span></td>
                        <?php elseif($dokumen_simpan_berjalan->opsi_surat_penjaluran == "SPJH"): ?>
                            <td style="background-color: green"><span><i class="fas fa-people-carry"></i></span></td>
                        <?php else: ?>
                            <td style=""><span><i class="fas fa-people-carry"></i></span></td>
                        <?php endif; ?>
                        <td>
                            <form action="<?php echo e(url('admin/detail_dokumen_simpan_berjalan')); ?>" method="get">
                                <?php echo e(csrf_field()); ?>

                                <input type="hidden" name="id_dokumen" value="<?php echo e($dokumen_simpan_berjalan->id_dokumen_simpan_berjalan); ?>">
                                <button type="submit" class="button"><span>Detail</span></button>
                            </form>
                        </td>
                        <td>
                            <form action="<?php echo e(url('admin/delete_dokumen_SPK')); ?>" method="post">
                                <?php echo e(csrf_field()); ?>

                                <input type="hidden" name="id_dokumen" value="<?php echo e($dokumen_simpan_berjalan->id_dokumen_simpan_berjalan); ?>">
                                <button type="submit" class="button"><span>Delete</span></button>
                            </form>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
                
            </table>
        </div>
    </section>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.admin_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Kuliah\Semester 8\Program TA\program_TA\tugas-akhir\resources\views/pages/admin/list_dokumen_simpan_berjalan.blade.php ENDPATH**/ ?>