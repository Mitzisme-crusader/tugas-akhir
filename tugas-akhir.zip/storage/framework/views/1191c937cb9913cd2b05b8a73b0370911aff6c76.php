<?php $__env->startSection('title'); ?>
<title>Admin</title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('style'); ?>
<link rel="stylesheet" href="<?php echo e(asset('css/admin.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('css/daftar_rekening.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="content">
    <section>
        <h1>Add New Rekening</h1>
        <?php if(Session::has('message')): ?>
            <h4 class="message"><?php echo e(Session::get('message')); ?></h4>
        <?php endif; ?>
        <form action="<?php echo e(url('admin/proses_add_rekening')); ?>" class = "form_add" method="post">
            <?php echo csrf_field(); ?>

            <div class="input-wrapper" id="select_nomor_COA">
                <select name="option_nomor_COA" id="option_nomor_COA" style="display:inline; width:100%">
                    <option value=""> Select Nomor COA</option>
                    <?php $__currentLoopData = $list_nomor_COA; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $nomor_COA): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option><?php echo e($nomor_COA->nomor_COA); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <span class="error-message"><?php echo e($errors->first('option_nomor_COA')); ?></span>
            </div>

            <div class="input-wrapper class_nomor_COA">
                <input type="input_nomor_COA" name="input_nomor_COA" id="input_nomor_COA"
                    value="<?php echo e(old('input_nomor_COA')); ?>">
                <label for="input_nomor_COA"><span>Nomor COA</span></label>
                <span class="error-message"><?php echo e($errors->first('input_nomor_COA')); ?></span>
            </div>

            <div class="input-wrapper">
                <input type="input_nama_jenis_COA" name="input_nama_jenis_COA" id="input_nama_jenis_COA"
                    value="<?php echo e(old('input_nama_jenis_COA')); ?>">
                <label for="input_nama_jenis_COA"><span>Nama jenis COA</span></label>
                <span class="error-message"><?php echo e($errors->first('input_nama_jenis_COA')); ?></span>
            </div>

            <div class="input-wrapper">
                <input type="input_total_COA" name="input_total_COA" id="input_total_COA"
                    value="<?php echo e(old('input_total_COA')); ?>">
                <label for="input_total_COA"><span>Total COA</span></label>
                <span class="error-message"><?php echo e($errors->first('input_total_COA')); ?></span>
            </div>

            <div class="input-wrapper">
                <input type="input_nama_rekening" name="input_nama_rekening" id="input_nama_rekening"
                    value="<?php echo e(old('input_nama_rekening')); ?>">
                <label for="input_nama_rekening"><span>Nama Rekening</span></label>
                <span class="error-message"><?php echo e($errors->first('input_nama_rekening')); ?></span>
            </div>

            <div class="input-wrapper">
                <input type="input_nomor_rekening" name="input_nomor_rekening" id="input_nomor_rekening"
                    value="<?php echo e(old('input_nomor_rekening')); ?>">
                <label for="input_nomor_rekening"><span>Nomor Rekening</span></label>
                <span class="error-message"><?php echo e($errors->first('input_nomor_rekening')); ?></span>
            </div>

            <div>
                <input type="checkbox" id="input_new_COA" name="input_new_COA" value="">

                <label class="label_checkbox_new_COA" for="input_new_COA">Add New COA</label>

                <button type="submit" class="button add_new_rekening"><span>Add Rekening</span></button>
            </div>
        </form>
    </section>

    <script>
        $(document).ready(function () {
            $("select").select2();

            $("#input_new_COA").change(function(){
                if($("#input_new_COA").is(":checked")){
                    $("#select_nomor_COA").css("display","none");
                    $("#option_nomor_COA").val("").change();
                    $("#option_nomor_COA").val("");

                    $("#input_nama_jenis_COA").val("");
                    $("#input_total_COA").val("");
                    $('#input_nama_jenis_COA').removeClass("not-empty");
                    $('#input_total_COA').removeClass("not-empty");

                    $(".class_nomor_COA").css("display","block");
                }
                else{
                    $("#select_nomor_COA").css("display","block");

                    $("#input_nama_jenis_COA").val("");
                    $("#input_total_COA").val("");
                    $('#input_nama_jenis_COA').removeClass("not-empty");
                    $('#input_total_COA').removeClass("not-empty");

                    $(".class_nomor_COA").css("display","none");
                }
            });

            $("#option_nomor_COA").change(function() {

                let nomor_COA = $('#option_nomor_COA option:selected').val();

                $.ajax({
                    type : 'GET',
                    url: "<?php echo e(url('admin/get_data_COA')); ?>"+'/?nomor_COA='+nomor_COA,
                    data: '',
                    success: function(data){
                        console.log(data);

                        $("#input_nama_jenis_COA").val(data['nomor_COA']['nama_jenis_COA']);
                        $('#input_nama_jenis_COA').addClass("not-empty");
                        $("#input_total_COA").val(data['nomor_COA']['total_COA']);
                        $('#input_total_COA').addClass("not-empty");
                        // $("#input_total_COA").val(data['customer']['alamat_customer'] + '- ' + data['customer']['provinsi_customer'] + '- ' + data['customer']['negara_customer']);

                        // $id_jenis_service_spk = data['dokumen_spk']['id_service'];

                    }
                });
            });
        });
    </script>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.admin_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Kuliah\Semester 8\Program TA\program_TA\tugas-akhir\resources\views/pages/admin/daftar_rekening.blade.php ENDPATH**/ ?>