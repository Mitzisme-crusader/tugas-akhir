<?php $__env->startSection('title'); ?>
<title>Admin</title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('style'); ?>
<link rel="stylesheet" href="<?php echo e(asset('css/admin.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="content" style="width: 75%">
    <section>
        <h1>List Dokumen SO untuk tagihan</h1>
        <div class="table-wrapper">
            <table>
                <thead>
                    <th>Nomor SO</th>
                    <th>Date Created</th>
                    <th>Total</th>
                    <th>Owing</th>
                    <th>Status</th>
                    <th>Detail</th>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $list_dokumen_SO; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dokumen_so): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($dokumen_so->nomor_so); ?></td>
                        <td><?php echo e($dokumen_so->tanggal_so); ?></td>
                        <td><?php echo e($dokumen_so->Total); ?></td>
                        <td><?php echo e($dokumen_so->hutang); ?></td>
                        <td>
                            <span>
                                <?php if($dokumen_so->hutang > 0): ?>
                                    Belum Lunas
                                <?php else: ?>
                                    Lunas
                                <?php endif; ?>
                            </span>
                        </td>
                        <td>
                            <form action="<?php echo e(url('admin/detail_tagihan_vendor')); ?>" method="get">
                                <?php echo e(csrf_field()); ?>

                                <input type="hidden" name="nomor_so" value="<?php echo e($dokumen_so->nomor_so); ?>">
                                <button type="submit" class="button"><span>Detail</span></button>
                            </form>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
                
            </table>
        </div>
    </section>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.admin_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Kuliah\Semester 8\Program TA\program_TA\tugas-akhir\resources\views/pages/admin/list_dokumen_SO_untuk_tagihan.blade.php ENDPATH**/ ?>