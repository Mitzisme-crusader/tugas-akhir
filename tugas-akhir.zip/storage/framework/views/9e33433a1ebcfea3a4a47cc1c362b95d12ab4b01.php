<?php $__env->startSection('title'); ?>
<title>Admin</title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('style'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('css/admin.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/list_document_SPK.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="content" style="width: 75%">
    <section>
        <h1 style="display:inline-block">List Dokumen SPK</h1>
        <div class="search-container">
            <form action="<?php echo e(url('admin/search_SPK')); ?>" method="GET" style="display: inline-block">
                <div style="display: inline-block">
                    <div style="display: block">
                        <input id ="query_search" type="text" placeholder="Search.." name="query_search">
                        <label style="height: 50px;width:50px"> In</label>
                        <select name="list_option_table" class="list_option_table" id="list_option_table">
                            <option value="id_dokumen_spk">ID dokumen</option>
                            <option value="judul_dokumen">Judul dokumen</option>
                            <option value="nama_customer">Nama Customer</option>
                            <option value="negara_customer">Negara Customer</option>
                        </select>
                    </div>
                    <div style="display: block">
                        <input type="date" class="input_search_date_tabel" name="range_date_search_awal" >
                        <label style="margin-left: 2px;margin-right:5px"> / </label>
                        <input type="date" class="input_search_date_tabel" name="range_date_search_akhir" value="<?php echo date('Y-m-d'); ?>">
                    </div>
                </div>
                <div style="display: inline-block;height:44px">
                    <button type="submit" style="display: inline"><i class="fa fa-search"></i></button>
                </div>
            </form>
        </div>
        <div class="table-wrapper">
            <table>
                <thead>
                    <th>Id_dokumen</th>
                    <th>Judul Dokumen</th>
                    <th>Nama Customer</th>
                    <th>Negara Customer</th>
                    <th>Nama Perusahaan Customer</th>
                    <th>Tanggal Dibuat</th>
                    <th>edit</th>
                    <th>delete</th>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $list_dokumen_SPK; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dokumen_SPK): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($dokumen_SPK->id_dokumen_spk); ?></td>
                        <td><?php echo e($dokumen_SPK->judul_dokumen); ?></td>
                        <td><?php echo e($dokumen_SPK->nama_customer); ?></td>
                        <td><?php echo e($dokumen_SPK->negara_customer); ?></td>
                        <td><?php echo e($dokumen_SPK->nama_perusahaan_customer); ?></td>
                        <td><?php echo e(date($dokumen_SPK->created_at)); ?></td>
                        <td>
                            <form action="<?php echo e(url('admin/edit_dokumen_SPK')); ?>" method="get">
                                <?php echo e(csrf_field()); ?>

                                <input type="hidden" name="id_dokumen" value="<?php echo e($dokumen_SPK->id_dokumen_spk); ?>">
                                <button type="submit" class="button"><span>Edit</span></button>
                            </form>
                        </td>
                        <td>
                            <form action="<?php echo e(url('admin/delete_dokumen_SPK')); ?>" method="post">
                                <?php echo e(csrf_field()); ?>

                                <input type="hidden" name="id_dokumen" value="<?php echo e($dokumen_SPK->id_dokumen_spk); ?>">
                                <button type="submit" class="button"><span>Delete</span></button>
                            </form>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
                
            </table>
        </div>
    </section>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.admin_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Kuliah\Semester 8\Program TA\program_TA\tugas-akhir\resources\views/pages/admin/list_dokumen_SPK.blade.php ENDPATH**/ ?>