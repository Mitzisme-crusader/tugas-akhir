<?php $__env->startSection('title'); ?>
<title>Admin</title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('style'); ?>
<link rel="stylesheet" href="<?php echo e(asset('css/admin.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="content" style="width: 75%">
    <section>
        <h1>List Tagihan Vendor</h1>
        <div class="table-wrapper">
            <table>
                <thead>
                    <th>Nomor SO</th>
                    <th>Date Created</th>
                    <th>Total</th>
                    <th>Owing</th>
                    <th>Status</th>
                    <th>Detail</th>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $list_tagihan_vendor; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tagihan_vendor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($tagihan_vendor->nomor_so); ?></td>
                        <td><?php echo e(date('d-m-Y',strtotime($tagihan_vendor->created_at))); ?></td>
                        <td><?php echo e($tagihan_vendor->total_service); ?></td>
                        <td><?php echo e($tagihan_vendor->hutang); ?></td>
                        <td>
                            <span>
                                <?php if($tagihan_vendor->hutang > 0): ?>
                                    Belum Lunas
                                <?php else: ?>
                                    Lunas
                                <?php endif; ?>
                            </span>
                        </td>
                        <td>
                            <form action="<?php echo e(url('admin/detail_tagihan_vendor')); ?>" method="get">
                                <?php echo e(csrf_field()); ?>

                                <input type="hidden" name="id_tagihan_vendor" value="<?php echo e($tagihan_vendor->id_tagihan_vendor); ?>">
                                <button type="submit" class="button"><span>Detail</span></button>
                            </form>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
                
            </table>
        </div>
    </section>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.admin_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Kuliah\Semester 8\Program TA\program_TA\tugas-akhir\resources\views/pages/admin/list_tagihan_vendor.blade.php ENDPATH**/ ?>