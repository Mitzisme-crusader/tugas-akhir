<?php $__env->startSection('title'); ?>
    <title>List User</title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('style'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('css/login_register.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="content">
    <div class="login-register-box">
        <h1>This is list</h1>
        <?php if(Session::has('message')): ?>
        <h4><?php echo e(Session::get('message')); ?></h4>
        <?php endif; ?>
    </div>
</div>
    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div ><span><?php echo e($user->email); ?></span></div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.user_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Kuliah\Semester 8\Program TA\program_TA\resources\views/pages/list_user.blade.php ENDPATH**/ ?>