<?php $__env->startSection('title'); ?>
<title>Admin</title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('style'); ?>
<link rel="stylesheet" href="<?php echo e(asset('css/admin.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="content" style="width: 75%">
    <section>
        <h1>List Dokumen SO</h1>
        <div class="table-wrapper">
            <table>
                <thead>
                    <th>Nomor SO</th>
                    <th>Date Created</th>
                    <th>Judul Dokumen SPK</th>
                    <th>Nama Customer</th>
                    <th>Alamat Customer</th>
                    <th>edit</th>
                    <th>delete</th>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $list_dokumen_SO; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dokumen_so): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($dokumen_so->nomor_so); ?></td>
                        <td><?php echo e($dokumen_so->tanggal_so); ?></td>
                        <td><?php echo e($dokumen_so->judul_dokumen_spk); ?></td>
                        <td><?php echo e($dokumen_so->nama_customer); ?></td>
                        <td>
                            <textarea cols="30" rows="4" readonly><?php echo e($dokumen_so->alamat_customer); ?></textarea>
                        </td>
                        <td>
                            <form action="<?php echo e(url('admin/edit_dokumen_so')); ?>" method="get">
                                <?php echo e(csrf_field()); ?>

                                <input type="hidden" name="id_dokumen_so" value="<?php echo e($dokumen_so->id_dokumen_so); ?>">
                                <button type="submit" class="button"><span>Edit</span></button>
                            </form>
                        </td>
                        <td>
                            <form action="<?php echo e(url('admin/delete_dokumen_so')); ?>" method="post">
                                <?php echo e(csrf_field()); ?>

                                <input type="hidden" name="id_dokumen_so" value="<?php echo e($dokumen_so->id_dokumen_so); ?>">
                                <button type="submit" class="button"><span>Delete</span></button>
                            </form>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
                
            </table>
        </div>
    </section>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.admin_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Kuliah\Semester 8\Program TA\program_TA\tugas-akhir\resources\views/pages/admin/list_dokumen_so.blade.php ENDPATH**/ ?>