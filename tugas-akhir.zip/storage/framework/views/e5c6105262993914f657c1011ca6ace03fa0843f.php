<?php $__env->startSection('title'); ?>
<title>Admin</title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('style'); ?>
<link rel="stylesheet" href="<?php echo e(asset('css/admin.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="content">
    <section>
        <h1>Add New Service</h1>
        <?php if(Session::has('message')): ?>
            <h4 class="message"><?php echo e(Session::get('message')); ?></h4>
        <?php endif; ?>
        <form action="<?php echo e(url('admin/proses_add_service')); ?>" class = "form_add" method="post">
            <?php echo csrf_field(); ?>
            <div class="input-wrapper">
                <input type="nama_service" name="nama_service" id="nama_service"
                    value="<?php echo e(old('nama_service')); ?>">
                <label for="nama_service"><span>Nama Service</span></label>
                <span class="error-message"><?php echo e($errors->first('nama_service')); ?></span>
            </div>
            <div class="input-wrapper">
                <input type="deskripsi_service" name="deskripsi_service" id="deskripsi_service"
                    value="<?php echo e(old('deskripsi_service')); ?>">
                <label for="deskripsi_service"><span>Deskripsi Service</span></label>
                <span class="error-message"><?php echo e($errors->first('deskripsi_service')); ?></span>
            </div>

            <div class="input-wrapper">
                <input type="biaya_service" name="biaya_service" id="biaya_service"
                    value="<?php echo e(old('biaya_service')); ?>">
                <label for="biaya_service"><span> Biaya Service</span></label>
                <span class="error-message"><?php echo e($errors->first('biaya_service')); ?></span>
            </div>

            <button type="submit" class="button"><span>Add Service</span></button>
        </form>
    </section>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.admin_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Kuliah\Semester 8\Program TA\program_TA\tugas-akhir\resources\views/pages/admin/add_service.blade.php ENDPATH**/ ?>