<nav>
    <ul>
        <li><a href="{{ url('/home') }}"><img src="{{ asset('images/logo.png') }}" alt="logo"></a></li>
        <li><a href="{{ url('/login') }}"><span>Login</span></a></li>
    </ul>
</nav>
