<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;

class tagihan_customer_seeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        //
    }
}
