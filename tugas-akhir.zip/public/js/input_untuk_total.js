$(document).ready(function () {
    $(".input_untuk_total_PPJK").keyup(function(e) {
        var nomor_urut = this.getAttribute("nomor_urut");
        console.log(nomor_urut);
        // var harga_unit = $("#input_quantity_PPJK".nomor_urut).val();
    });

});
